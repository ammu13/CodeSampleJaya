//
//  Helper.swift
//  PhotoGallery
//
//  Created by Jaya on 25/05/23.
//

import Foundation
import UIKit
final class Helper {
enum Errors: Error {
    case dataDoesNotExist(String), jsonSerialisationError(Error), requestError(String), invalidUrl, invalidResponse, serverError(String), noNetworkConnection, noLocation, customError(String)
    
}
class func parse<D: Decodable>(data: Data?, dateDecodingStrategy: JSONDecoder.DateDecodingStrategy = .iso8601) -> Result<[D]> {
    guard let data = data else {
        print("Data is nil")
         return .failure(Errors.customError("dataDoesNotExist"))
    }
    do {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = dateDecodingStrategy
        let values = try decoder.decode([D].self, from: data)
        return .success(values)
    } catch {
        print("Parsing error: \(error)")
        return .failure(error)
    }
}
}
extension UIViewController {
    var isPresenting: Bool {
        if self.view.subviews.filter({ $0.accessibilityIdentifier == "Loader"  }).first as? Loader != nil {
            return true
        }
        return false
    }
    func startLoading(with message: String) {
        if self.isPresenting {
            print("loading \(message) returned")
            return
        }
        guard let loaderView: Loader = .loadNib() else {
            return
        }
        print("loading \(message) started")
        loaderView.message = message
        loaderView.frame = self.view.bounds
        self.view.addSubview(loaderView)
    }
    
    func stopLoading(_ completion:(() -> Void)? = nil) {
        DispatchQueue.main.async { [self] in
            if let loaderView = self.view.subviews.filter({ $0.accessibilityIdentifier == "Loader" }).first as? Loader, self.isPresenting {
            loaderView.stopAnimation(completion)
        }
        }
    }
    func showAlert(title: String, message: String, actionTitle: String = "OK", completion: (() -> Void)? = nil) {
            let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
            let action = UIAlertAction(title: actionTitle, style: .default) { _ in
                completion?()
            }
            alertController.addAction(action)
            present(alertController, animated: true, completion: nil)
        }
}
extension UIView {
       class func loadNib<T: UIView>() -> T? {
            guard let nib = Bundle.main.loadNibNamed(String.init(describing: T.self), owner: nil, options: nil)?.first as? T else {
                return nil
            }
            return nib
        }
    }
