//
//  ViewController.swift
//  PhotoGallery
//
//  Created by Jaya on 25/05/23.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout,UIScrollViewDelegate {
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!
    
   // var photos: PhotoResponse = PhotoResponse(photos: [])
    var photos: [Photo] = []
    let pageSize = 10
    var currentPage = 1
    var currentPageIndex = 0
    var isLoading = false
    
    fileprivate func setUp() {
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.isPagingEnabled = true
        collectionView.register(Photocustomcell.self, forCellWithReuseIdentifier: "Photocustomcell")
        pageControl.numberOfPages =  5//calculateTotalNumberOfPages()
        pageControl.currentPage = 0
        
    }
    func calculateTotalNumberOfPages() -> Int {
        let totalNumberOfPhotos = photos.count
        let totalNumberOfPages = (totalNumberOfPhotos + pageSize - 1) / pageSize
        return totalNumberOfPages
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUp()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        startLoading(with: "Loading Photos")
        fetchDatas()
    }
    
    // MARK: - UICollectionViewDataSource
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let startIndex = (currentPage - 1) * pageSize
            let endIndex = min(startIndex + pageSize, photos.count)
            return endIndex - startIndex
        //return photos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Photocustomcell", for: indexPath) as! Photocustomcell
        let startIndex = (currentPage - 1) * pageSize
        let photoIndex = startIndex + indexPath.item
        let photo = photos[photoIndex]
        currentPageIndex = indexPath.item
        cell.configure(with: photo)
        return cell
//
//        let photo = photos[indexPath.item]
//        cell.configure(with: photo)
//        return cell
    }
    
    // MARK: - UICollectionViewDelegateFlowLayout
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let itemWidth = collectionView.bounds.width / 2 - 5
        let itemHeight = itemWidth
        return CGSize(width: itemWidth, height: itemHeight)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let photo = photos[indexPath.item]
        let page = indexPath.item / pageSize + 1 
        currentPage = page
        showFullScreenImage(photo)
    }
    func loadPage(atIndex index: Int) {
        currentPageIndex = index
        let pageOffset = index * pageSize
       
    }

    func showFullScreenImage(_ photo: Photo) {
        guard let imageURL = URL(string: photo.url) else {
            return
        }
        
        // Fetch the full-size image data
        let task = URLSession.shared.dataTask(with: imageURL) { (data, response, error) in
            if let error = error {
                print("Error loading full-size image:", error)
                return
            }
            
            guard let data = data, let image = UIImage(data: data) else {
                print("Invalid image data")
                return
            }
            DispatchQueue.main.async {
                let imgViewExpand = UIImageView(image: image)
                imgViewExpand.contentMode = .scaleAspectFit
                imgViewExpand.backgroundColor = .black
                
                let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.dismissVC(_:)))
                imgViewExpand.addGestureRecognizer(tapGesture)
                imgViewExpand.isUserInteractionEnabled = true
                
                let secondVC = UIViewController()
                secondVC.view.addSubview(imgViewExpand)
                imgViewExpand.translatesAutoresizingMaskIntoConstraints = false
                
                NSLayoutConstraint.activate([
                    imgViewExpand.leadingAnchor.constraint(equalTo: secondVC.view.leadingAnchor),
                    imgViewExpand.trailingAnchor.constraint(equalTo: secondVC.view.trailingAnchor),
                    imgViewExpand.topAnchor.constraint(equalTo: secondVC.view.topAnchor),
                    imgViewExpand.bottomAnchor.constraint(equalTo: secondVC.view.bottomAnchor)
                ])
                
                self.present(secondVC, animated: true, completion: nil)
            }
        }
        
        task.resume()
    }

    @objc func dismissVC(_ sender: UITapGestureRecognizer) {
        self.dismiss(animated: true, completion: nil)
    }

    // MARK: - Pagination

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y
        let contentHeight = scrollView.contentSize.height
        let scrollViewHeight = scrollView.frame.height
        let totalPages = Int(ceil(Double(photos.count) / Double(pageSize)))
        if offsetY > contentHeight - scrollViewHeight {
           
            if currentPage < totalPages {
                currentPage += 1
                collectionView.reloadData()
            }
        }
    }

    
    func fetchDatas() {
        isLoading = true
        
        let urlString = "https://jsonplaceholder.typicode.com/photos"
        guard let url = URL(string: urlString) else {
            isLoading = false
            self.stopLoading()
            self.showAlert(title: "Error", message: "URL is not valid")
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let error = error {
                print("Error fetching photos:", error)
                self.isLoading = false
                self.stopLoading()
                self.showAlert(title: "Error", message: "Error fetching photos")
                return
            }
            
            guard let data = data else {
                print("No data received")
                self.isLoading = false
                self.stopLoading()
                self.showAlert(title: "Error", message: "Nil data received")
                return
            }
            
            do {
                let result: Result<[Photo]> = Helper.parse(data: data)
                self.photos = try result.getValue()
                DispatchQueue.main.async {
                    self.collectionView.reloadData()
                    self.isLoading = false
                }
            } catch {
                print("Error decoding JSON:", error)
                self.showAlert(title: "Error", message: "Issue in loading the data")
                self.isLoading = false
            }
            self.stopLoading()
        }
        
        task.resume()
    }
    
    // MARK: - Full-Screen Image


}

