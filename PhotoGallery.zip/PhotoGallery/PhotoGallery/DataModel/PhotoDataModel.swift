//
//  PhotoDataModel.swift
//  PhotoGallery
//
//  Created by Jaya on 25/05/23.
//

import Foundation

//URL : https://jsonplaceholder.typicode.com/photos
// MARK: - PhotoElement

protocol JSONCodable: Codable {
    init(data: Data, decoder: JSONDecoder) throws
    init(_ json: String, using encoding: String.Encoding) throws
}

extension JSONCodable {
    init(data: Data, decoder: JSONDecoder = .init()) throws {
        self = try decoder.decode(Self.self, from: data)
    }
    
    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }
    
    
}

struct Photo: JSONCodable {
    let albumID, id: Int
    let title: String
    let url, thumbnailURL: String

    enum CodingKeys: String, CodingKey {
        case albumID = "albumId"
        case id, title, url
        case thumbnailURL = "thumbnailUrl"
    }
    
   
}
enum Result<T> {
    case success(T), failure(Error)
    
    /// Returns the success value from the result
    ///
    /// - Returns: success value
    /// - Throws: error
    func getValue() throws -> T {
        switch self {
        case .success(let value): return value
        case .failure(let error): throw error
        }
    }
}


struct PhotoResponse: JSONCodable {
    let photos: [Photo]
}

